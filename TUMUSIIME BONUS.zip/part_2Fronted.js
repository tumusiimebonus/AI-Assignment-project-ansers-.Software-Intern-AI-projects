import { useState, useEffect } from "react";
import axios from "axios";

export default function ReportForm() {
  const [reportText, setReportText] = useState("");
  const [currentResult, setCurrentResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [translatedOutcome, setTranslatedOutcome] = useState("");
  const [history, setHistory] = useState([]);
  const [historyTranslations, setHistoryTranslations] = useState({});

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const response = await axios.get("http://localhost:8000/reports");
      setHistory(response.data);
    } catch (error) {
      console.error("Error fetching history:", error);
      alert("Unable to fetch report history.");
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    if (file.type !== "text/plain") {
      alert("Please upload a plain text (.txt) file.");
      return;
    }
    try {
      const text = await file.text();
      setReportText(text);
    } catch (error) {
      console.error("Error reading file:", error);
      alert("Failed to read file.");
    }
  };

  const handleSubmit = async () => {
    if (!reportText.trim()) {
      alert("Enter or upload a medical report before submitting.");
      return;
    }
    setLoading(true);
    try {
      const response = await axios.post("http://localhost:8000/process-report", { report: reportText });
      setCurrentResult(response.data);
      setTranslatedOutcome("");
      fetchHistory();
    } catch (error) {
      console.error("Error processing report:", error);
      alert("Failed to process the report.");
    } finally {
      setLoading(false);
    }
  };

  const translateOutcome = async (text, id = null) => {
    if (!text) return;
    try {
      const response = await axios.post("http://localhost:8000/translate", { text, lang: "fr" });
      const translatedText = response.data.translated_text;
      if (id === null) {
        setTranslatedOutcome(translatedText);
      } else {
        setHistoryTranslations((prev) => ({ ...prev, [id]: translatedText }));
      }
    } catch (error) {
      console.error("Translation error:", error);
      alert("Failed to translate outcome.");
    }
  };

  return (
    <div className="p-6 max-w-lg mx-auto">
      <h2 className="text-xl font-bold mb-3">Medical Report Submission</h2>

      <input
        type="file"
        accept=".txt"
        onChange={handleFileUpload}
        className="mb-2"
      />

      <textarea
        className="border p-2 w-full mb-2"
        rows={8}
        placeholder="Type or paste medical report here..."
        value={reportText}
        onChange={(e) => setReportText(e.target.value)}
      />

      <button
        onClick={handleSubmit}
        disabled={loading}
        className="bg-blue-500 text-white px-4 py-2 mt-2 rounded"
      >
        {loading ? "Processing..." : "Process Report"}
      </button>

      {currentResult && (
        <div className="mt-4 border p-4 rounded bg-gray-50 shadow">
          <h3 className="font-bold mb-2">Processed Report</h3>
          <p><b>Drug:</b> {currentResult.drug || "N/A"}</p>
          <p><b>Adverse Events:</b> {currentResult.adverse_events?.join(", ") || "None"}</p>
          <p><b>Severity:</b> {currentResult.severity || "Unknown"}</p>
          <p>
            <b>Outcome:</b> {currentResult.outcome || "Unknown"}{" "}
            {translatedOutcome && <span>(French: {translatedOutcome})</span>}
          </p>
          <button
            onClick={() => translateOutcome(currentResult.outcome)}
            className="mt-2 bg-green-500 text-white px-3 py-1 rounded"
          >
            Translate Outcome
          </button>
        </div>
      )}

      <div className="mt-6">
        <h3 className="text-lg font-bold mb-2">Report History</h3>
        {history.length === 0 && <p>No reports processed yet.</p>}

        {history.map((rep, index) => (
          <div key={index} className="border p-3 rounded mb-2 bg-gray-50 shadow">
            <p><b>Drug:</b> {rep.drug || "N/A"}</p>
            <p><b>Adverse Events:</b> {rep.adverse_events?.join(", ") || "None"}</p>
            <p><b>Severity:</b> {rep.severity || "Unknown"}</p>
            <p>
              <b>Outcome:</b> {rep.outcome || "Unknown"}{" "}
              {historyTranslations[index] && <span>(French: {historyTranslations[index]})</span>}
            </p>
            <button
              onClick={() => translateOutcome(rep.outcome, index)}
              className="mt-1 bg-green-500 text-white px-2 py-1 rounded"
            >
              Translate Outcome
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
